require 'test_helper'

class IntroductionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
