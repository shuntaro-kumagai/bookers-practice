require 'test_helper'

class IntroductionsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get introductions_index_url
    assert_response :success
  end

  test "should get show" do
    get introductions_show_url
    assert_response :success
  end

  test "should get new" do
    get introductions_new_url
    assert_response :success
  end

  test "should get edit" do
    get introductions_edit_url
    assert_response :success
  end

end
